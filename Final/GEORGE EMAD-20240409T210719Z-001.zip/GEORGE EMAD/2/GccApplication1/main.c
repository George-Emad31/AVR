#include <avr/io.h>
#include <util/delay.h>

#define F_CPU 16000000UL  // 16 MHz clock speed

#define SET_BIT(PORT,BIT) PORT |= (1<<BIT)
#define CLEAR_BIT(PORT,BIT) PORT &= ~(1<<BIT)

int main(void)
{
	DDRC = 0xFF; // Set PORTC as output (for the LEDs and buzzer)
	PORTC = 0xFF; // Turn off LEDs initially (negative logic)

	while(1)
	{
		for(int i = 0; i < 3; i++)
		{
			CLEAR_BIT(PORTC, i); // Turn on LED (negative logic)
			_delay_ms(500); // Delay for half a second
			SET_BIT(PORTC, i); // Turn off LED (negative logic)
		}

		CLEAR_BIT(PORTC, 3); // Turn on buzzer (assuming negative logic)
		_delay_ms(2000); // Delay for 2 seconds
		SET_BIT(PORTC, 3); // Turn off buzzer
	}

	return 0;
}
