#include <avr/io.h>

#define F_CPU 1000000UL  // 1 MHz clock speed
#include <util/delay.h>

#define SET_BIT(PORT,BIT) PORT |= (1<<BIT)
#define CLEAR_BIT(PORT,BIT) PORT &= ~(1<<BIT)

int main(void)
{
	DDRB = 0x00; // Set PORTB as input (for the push buttons)
	PORTB = 0xFF; // Enable pull-up resistors on PORTB

	DDRC = 0xFF; // Set PORTC as output (for the LEDs)
	PORTC = 0x00; // Turn off LEDs initially

	while(1)
	{
		if(PINB & (1<<PB0)) // If push button 1 is pressed
		{
			SET_BIT(PORTC, PC0); // Turn on LED 1
		}
		else
		{
			CLEAR_BIT(PORTC, PC0); // Turn off LED 1
		}

		if(PINB & (1<<PB1)) // If push button 2 is pressed
		{
			SET_BIT(PORTC, PC1); // Turn on LED 2
		}
		else
		{
			CLEAR_BIT(PORTC, PC1); // Turn off LED 2
		}
	}

	return 0;
}
