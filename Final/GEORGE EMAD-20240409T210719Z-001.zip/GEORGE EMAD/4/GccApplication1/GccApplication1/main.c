#include <avr/io.h>
#include <avr/interrupt.h>

#define F_CPU 1000000UL  // 1 MHz clock speed

volatile uint8_t count = 0; // Initialize count

ISR(INT2_vect) // Interrupt service routine for INT2
{
	if(count < 9) // If count is less than 9
	{
		count++; // Increment count
	}
	else
	{
		count = 0; // Reset count to 0 if it reaches 9
	}
}

void INT2_Init()
{
	MCUCSR = (1<<ISC2); // Falling edge generates interrupt request
	GICR = (1<<INT2); // Enable INT2
	sei(); // Enable global interrupts
}

int main(void)
{
	DDRC = 0x0F; // Set first 4 pins of PORTC as output (for the 74LS47 decoder inputs)
	DDRB &= ~(1<<PB2); // Set PB2 as input (for the switch)

	INT2_Init(); // Initialize INT2

	while(1)
	{
		PORTC = (PORTC & 0xF0) | (count & 0x0F); // Send count to 74LS47 decoder inputs
	}

	return 0;
}
