#include <avr/io.h>
#include <util/delay.h>

#define F_CPU 1000000UL  // 1 MHz clock speed

#define SET_BIT(PORT,BIT) PORT |= (1<<BIT)
#define CLEAR_BIT(PORT,BIT) PORT &= ~(1<<BIT)

// Array to hold the binary values for numbers 0-9 for the 7-segment display
uint8_t numbers[] = {0b0111111, 0b0000110, 0b1011011, 0b1001111, 0b1100110, 0b1101101, 0b1111101, 0b0000111, 0b1111111, 0b1101111};

int main(void)
{
	DDRD &= ~(1<<PD2); // Set PD2 as input (for the push button 1)
	DDRD &= ~(1<<PD3); // Set PD3 as input (for the push button 2)
	PORTD |= (1<<PD2); // Enable pull-up resistor on PD2
	PORTD |= (1<<PD3); // Enable pull-up resistor on PD3

	DDRA = 0xFF; // Set PORTA as output (for the 7-segment display)
	DDRC |= (1<<PC6); // Set PC6 as output (for the common pin of the 7-segment display)

	uint8_t count = 0; // Initialize count

	while(1)
	{
		if(!(PIND & (1<<PD2)) && count < 9) // If push button 1 is pressed and count is less than 9
		{
			_delay_ms(200); // Increased debounce delay
			if(!(PIND & (1<<PD2))) // Check button state again after delay
			{
				count++; // Increment count
			}
		}

		if(!(PIND & (1<<PD3)) && count > 0) // If push button 2 is pressed and count is more than 0
		{
			_delay_ms(200); // Increased debounce delay
			if(!(PIND & (1<<PD3))) // Check button state again after delay
			{
				count--; // Decrement count
			}
		}

		PORTA = numbers[count]; // Display count on 7-segment display
		CLEAR_BIT(PORTC, PC6); // Enable the 7-segment display (assuming negative logic)
	}

	return 0;
}
